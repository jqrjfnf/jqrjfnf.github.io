Place your own .mp4 or .webm video files in this folder, then add entries for them in ../videos.json.
