# Nova — ad-free personal video site (GitHub Pages only)

Nova is a static, YouTube-inspired video library. It has a responsive layout, search, video cards, a built-in HTML video player, category filtering, and locally saved favourites. It does not use YouTube, a YouTube API, Cloudflare, a backend, or an ad network.

## Add your own video

1. Put a video file in the `videos/` folder, e.g. `videos/trip.mp4`.
2. Open `videos.json`.
3. Add or edit an entry. `src` must match the file path exactly:

```json
[
  {
    "id": "trip-2026",
    "title": "Summer trip",
    "description": "A short video from my trip.",
    "src": "videos/trip.mp4",
    "thumbnail": "",
    "category": "video"
  }
]
```

Use `"category": "short"` for the Shorts filter. For best compatibility, use MP4 with H.264 video and AAC audio. Keep each `id` unique. JSON must use double quotes and must not have a comma after the final item.

To add a thumbnail, put an image in the repo and set e.g. `"thumbnail": "thumbnails/trip.jpg"` (create the folder if needed).

## Publish on GitHub Pages from a phone

1. Create a repository named exactly `YOUR-USERNAME.github.io` (or use your existing user site repository).
2. Upload `index.html`, `videos.json`, and the `videos/` folder to the repository's root. Keep the same folder structure.
3. In the repository, open **Settings → Pages**. Under build/deployment, choose **Deploy from a branch**, select `main` and `/(root)`, then Save. If the repository is already a Pages site, this may already be set up.
4. Wait for the Pages deployment, then open `https://YOUR-USERNAME.github.io`.

On a phone, GitHub's website may make folder uploads awkward. You can create the `videos` folder by adding a file whose path starts with `videos/`, or upload files using the GitHub mobile app if available. Large video uploads may fail in the browser; see the limits below.

## Important limits

GitHub Pages is static hosting, not a general video hosting service. GitHub recommends keeping a published Pages site repository at **1 GB or less** and applies a **soft bandwidth limit of 100 GB per month**. These are limits/guidelines, not a promise of unlimited video delivery. A single video watched by 1,000 people can use many gigabytes depending on its size and how much each viewer watches. Large files also make Git operations and site updates slow.

GitHub blocks regular Git files larger than **100 MiB**. Files larger than **50 MiB** trigger a warning. Git LFS has separate restrictions and is not a good way to stream a library from GitHub Pages; Pages does not provide a media CDN or a user-upload system. GitHub Pages has a soft build limit of 10 builds per hour, though pushes may be queued/deployed differently.

For a small personal collection, compress videos and keep the total repository small. For a large library or lots of viewers, use a dedicated video host/object storage/CDN instead. Don't commit private or sensitive videos: files in a public repository are public, and a public Pages site is viewable by anyone.

## What this version can and cannot do

- Can: show your own MP4/WebM files, search titles/descriptions, filter Shorts, play videos, and save favourites in that browser.
- Cannot: accept uploads from visitors, provide accounts, sync favourites across devices, host comments/likes shared among users, or keep videos private with GitHub Pages alone.
- “Ad-free” means Nova itself does not insert ads. GitHub Pages does not normally add ads to your site, but this is not a guarantee that your viewers' browsers, networks, or extensions will never show unrelated ads.

Check current official limits before relying on the site:
- https://docs.github.com/en/pages/getting-started-with-github-pages/github-pages-limits
- https://docs.github.com/en/repositories/working-with-files/managing-large-files/about-large-files-on-github
